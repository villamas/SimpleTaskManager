# Simple Task Manager — Requirements Analysis

**Version:** 0.2  
**Status:** Approved  
**Project:** Basic POC for an AI-assisted development exercise

## 1. Project overview

Build a simple local web application for a single user to manage daily tasks. The application is a hands-on exercise, not a production or enterprise system. The scope covers CRUD, status management, filtering and SQLite persistence.

Constraints: localhost only; single user; no authentication or authorization; no cloud infrastructure or external runtime services; synthetic data only; follow KISS and YAGNI and avoid unnecessary complexity.

## 2. Functional requirements

| ID | Name | Requirement |
|---|---|---|
| FR-001 | Create task | Create a task with a valid title and default Pending status. |
| FR-002 | View tasks | View all stored tasks in oldest-first creation order. |
| FR-003 | Edit task | Modify the title of an existing task regardless of status. |
| FR-004 | Delete task | Permanently delete an existing task after browser confirmation. |
| FR-005 | Manage status | Change status between Pending and Completed. |
| FR-006 | Filter tasks | Filter by All, Pending or Completed; All is selected when the application opens. |
| FR-007 | Persist tasks | Persist tasks and changes in a local SQLite database across application restarts. |

### Task attributes

| Attribute | Required | Description |
|---|---|---|
| ID | Yes | Unique, automatically assigned identifier. |
| Title | Yes | Text of 1–255 characters after trimming whitespace. |
| Status | Yes | Pending or Completed; defaults to Pending. |

No additional task attributes are required.

## 3. Non-functional requirements

| ID | Category | Requirement |
|---|---|---|
| NFR-001 | Local execution | Operate entirely on localhost. |
| NFR-002 | Independence | Operate without internet connectivity or external runtime services after initial setup. |
| NFR-003 | Performance | Provide basic responsiveness during normal local usage without unnecessary delays or freezing. |
| NFR-004 | Usability | All user-facing task management operations are accessible through the web interface without command-line interaction. |
| NFR-005 | Reliability | Successfully saved data remains available after a normal application restart. |
| NFR-006 | Error handling | Handle invalid inputs and operations targeting nonexistent tasks gracefully, displaying understandable errors without crashing. |
| NFR-007 | Maintainability | Follow KISS and YAGNI; avoid unnecessary dependencies, abstractions and features. |
| NFR-008 | Security | Do not expose services to external network interfaces. |
| NFR-009 | Data privacy | Use synthetic data only in development, demonstrations and testing. |
| NFR-010 | Browser compatibility | Support Microsoft Edge or Google Chrome; testing either browser is sufficient. |

## 4. Business rules

| ID | Rule |
|---|---|
| BR-001 | Every task has a unique, automatically assigned identifier. |
| BR-002 | Every task has a non-empty title. |
| BR-003 | Titles contain 1–255 characters after trimming leading and trailing whitespace. |
| BR-004 | Each task has exactly one status: Pending or Completed. |
| BR-005 | New tasks default to Pending. |
| BR-006 | Status changes are reversible. |
| BR-007 | Duplicate titles are permitted. |
| BR-008 | Browser confirmation is required for deletion. Confirmation permanently removes the task from the database; cancellation leaves it unchanged. |
| BR-009 | Filtering does not modify stored data. |
| BR-010 | Editing a title does not automatically change status. |
| BR-011 | Both Pending and Completed tasks may be edited. |
| BR-012 | All task lists, including filtered results, use oldest-first creation order. |
| BR-013 | All is the default filter when the application opens. |
| BR-014 | Operations targeting nonexistent tasks must not modify other stored tasks. |

## 5. Acceptance criteria

### Functional

| ID | Requirement | Given | When | Then |
|---|---|---|---|---|
| AC-001 | FR-001 | Valid title | Create task | Exactly one task is saved with unique ID and Pending status. |
| AC-002 | FR-001 | Empty or whitespace-only title | Attempt creation | Error displayed; no task saved. |
| AC-003 | FR-002 | Three stored tasks | View all | All three displayed. |
| AC-004 | FR-002 | No stored tasks | Open list | Empty list or appropriate empty-state message displayed. |
| AC-005 | FR-003 | Existing task | Save valid updated title | Title updated without changing ID or status. |
| AC-006 | FR-003 | Existing task | Submit invalid title | Error displayed; original task unchanged. |
| AC-007 | FR-004 | Existing task | Request deletion and confirm browser dialog | Task permanently removed from list and database. |
| AC-008 | FR-005 | Pending task | Mark Completed | Completed status saved. |
| AC-009 | FR-005 | Completed task | Mark Pending | Pending status saved. |
| AC-010 | FR-006 | Mixed statuses | Select Pending | Only Pending tasks displayed. |
| AC-011 | FR-006 | Mixed statuses | Select Completed | Only Completed tasks displayed. |
| AC-012 | FR-006 | Active status filter | Select All | All stored tasks displayed. |
| AC-013 | FR-007 | Successfully created, edited, completed and deleted tasks | Restart application | All saved changes remain consistent, including deletions. |
| AC-014 | FR-001, FR-003 | Title exceeding 255 characters after trimming | Attempt save | Error displayed; operation rejected. |
| AC-023 | FR-004 | Existing task | Request deletion and cancel confirmation | Task unchanged. |
| AC-024 | FR-001 | Existing title | Create another task with same title | Both tasks exist with different IDs. |
| AC-025 | FR-002 | Multiple sequentially created tasks | View list | Oldest-first creation order. |
| AC-026 | FR-006 | Stored tasks with different statuses | Open application | All filter selected by default. |
| AC-027 | FR-003 | Completed task | Edit title | Title updated; status remains Completed. |
| AC-028 | FR-003, FR-004, FR-005 | Nonexistent task ID | Attempt edit, deletion or status change | Understandable error returned; other tasks unchanged. |
| AC-029 | FR-001, FR-003 | Valid title with surrounding whitespace | Save task | Title stored without leading or trailing whitespace. |
| AC-030 | FR-001, FR-003 | Title of exactly 1 or 255 characters after trimming | Save task | Title accepted. |
| AC-031 | FR-006 | Multiple stored tasks | Switch filters | Stored data unchanged; matching tasks retain oldest-first order. |

### Non-functional

| ID | Requirement | Verification criteria |
|---|---|---|
| AC-015 | NFR-001, NFR-008 | Accessible through localhost and inaccessible from another device on the local network. |
| AC-016 | NFR-002 | All core operations work without internet connectivity after initial setup. Verify runtime independence by inspecting dependencies and confirming all frontend resources and API requests are local, as agreed in technical design v0.2. |
| AC-017 | NFR-003 | Core operations complete during normal manual testing without noticeable unnecessary delays or interface freezing. |
| AC-018 | NFR-004 | All user-facing operations in FR-001–FR-006 can be performed through the web interface without command-line interaction. |
| AC-019 | NFR-005 | Successfully saved data remains consistent after a normal application restart. |
| AC-020 | NFR-006 | Invalid inputs and nonexistent-task operations produce understandable errors without crashing or modifying unrelated tasks. |
| AC-021 | NFR-007 | Human review confirms no unnecessary features, dependencies or abstractions. |
| AC-022 | NFR-009 | All test and demonstration records contain synthetic data only. |
| AC-032 | NFR-010 | All user-facing functional acceptance tests pass in either Edge or Chrome. |

UI validation (AC-018) is separate from persistence validation (AC-013 and AC-019).

## 6. Assumptions and resolved questions

| ID | Assumption |
|---|---|
| AS-001 | One user interacts with the application at a time. |
| AS-002 | Access is through a local desktop browser. |
| AS-003 | Data is stored on the same machine as the application. |
| AS-004 | Small volumes of task data are expected. |
| AS-005 | Initial dependency installation may require internet access; runtime does not. |
| AS-006 | No existing data migration or integration is required. |

| ID | Approved resolution |
|---|---|
| OQ-001 | ID, title and status only. |
| OQ-002 | Mandatory title, 1–255 characters after trimming. |
| OQ-003 | Default status Pending. |
| OQ-004 | Duplicate titles allowed. |
| OQ-005 | Native browser deletion confirmation required. |
| OQ-006 | Permanent deletion; no recovery. |
| OQ-007 | Oldest-first creation order. |
| OQ-008 | All is the default filter. |
| OQ-009 | Completed tasks remain editable. |
| OQ-010 | Edge or Chrome; test either. |
| OQ-011 | Basic responsiveness, no quantitative threshold or load testing. |
| OQ-012 | No additional task attributes. |

## 7. Out of scope

- Authentication, authorization, multiple users, roles and permissions.
- Sharing, collaboration, cloud deployment, synchronization, external APIs and third-party integrations.
- Descriptions, timestamps, priorities, categories, tags, due dates, reminders, notifications, recurring tasks and subtasks.
- Search, advanced filtering, user-configurable sorting and pagination.
- Undo, recycle bin, recovery, import, export and automated backups.
- Reporting, analytics, dashboards and native mobile applications.
- Performance benchmarking, load testing, cross-browser testing and database failure simulation.
- Production-grade scalability and high availability.

## 8. Human approval and change control

HA-001 through HA-010 are approved: functional scope, task attributes, validation, status management, deletion, display defaults, non-functional requirements, browser compatibility, scope exclusions and complete baseline. Version 0.2 is the authoritative approved requirements baseline. There are 7 functional requirements, 10 non-functional requirements, 14 business rules and 32 acceptance criteria. No open requirements decisions remain. Changes require explicit human approval.
