# Simple Task Manager — Technical Design

**Version:** 0.2  
**Status:** Approved  
**Requirements baseline:** v0.2 (Approved)  
**Project:** Basic practical POC for AI-assisted development  
**Repository:** `C:\code\SimpleTaskManager`  
**Branch:** `feature/createSimpleTask`

## 1. Architecture

One ASP.NET Core Minimal API web application serves a static HTML/CSS/Vanilla JavaScript frontend and JSON API on localhost. Endpoint handlers enforce business rules and use EF Core DbContext directly to access a local SQLite database. The browser uses same-origin HTTP requests. A separate xUnit project provides integration tests.

Use .NET 11, EF Core SQLite, WebApplicationFactory (Microsoft.AspNetCore.Mvc.Testing), Microsoft.NET.Test.Sdk, xUnit and its test runner. Verify exact compatible package versions during setup. The reported environment is Windows with SDK 11.0.100, Git, Node.js/npm and configured Playwright MCP in Codex. Node/npm are not application runtime dependencies.

This architecture avoids separate servers, frontend builds, CORS configuration and unnecessary abstractions. Do not use Clean Architecture, Repository Pattern, CQRS, MediatR, frontend frameworks, Docker, cloud services or CI/CD pipelines.

## 2. Solution and folder structure

```text
SimpleTaskManager/
  SimpleTaskManager.slnx
  src/
    SimpleTaskManager.Api/
      SimpleTaskManager.Api.csproj
      Program.cs
      appsettings.json
      Models/TaskItem.cs
      Data/AppDbContext.cs
      Contracts/TaskContracts.cs
      Endpoints/TaskEndpoints.cs
      wwwroot/
        index.html
        styles.css
        app.js
      App_Data/tasks.db
  tests/
    SimpleTaskManager.Tests/
      SimpleTaskManager.Tests.csproj
      TaskApiTests.cs
  Assessment/
  .gitignore
  README.md
```

Program configures hosting, static files, database initialization, endpoints and error handling. Models hold the task entity; Data holds EF configuration; Contracts hold request/response models; Endpoints contain API handlers and rules. The database is generated locally outside the public web directory. Tests remain separate from application compilation.

Preserve the existing feature branch, Assessment exclusion, repository contents and unrelated changes. Ignore generated databases and journal files, build artifacts and temporary test files. No automatic commits, pushes, merges or branch switching. Verify repository state and exclusions before changes.

## 3. SQLite schema

| Column | Type | Constraints |
|---|---|---|
| Id | INTEGER | Primary key, automatically generated, AUTOINCREMENT. |
| Title | TEXT | NOT NULL; simple CHECK for length 1–255. |
| Status | TEXT | NOT NULL; default Pending; CHECK restricting values to Pending or Completed. |

Only one application table, Tasks. Duplicate titles allowed; no additional attributes, relationships or indexes beyond the primary key. SQLite internal AUTOINCREMENT metadata is not an application entity. Sort by ascending ID; gaps are acceptable and previously committed IDs are not reused. No timestamps are needed.

Database path: `src/SimpleTaskManager.Api/App_Data/tasks.db`, resolved relative to the application content root. Create the directory and empty database automatically on first startup using EnsureCreated; reuse the database thereafter. No migrations for the fixed schema. EnsureCreated does not upgrade existing schemas; any schema change requires review.

API title validation is authoritative. EF Core HasMaxLength alone does not enforce SQLite string length.

## 4. REST API

| Method | Route | Purpose | Requirement | Success |
|---|---|---|---|---|
| GET | `/api/tasks` | List/filter tasks | FR-002, FR-006 | 200, array |
| GET | `/api/tasks/{id}` | Retrieve task | FR-003 | 200, task |
| POST | `/api/tasks` | Create task | FR-001 | 201, task and Location header |
| PATCH | `/api/tasks/{id}` | Update title only | FR-003 | 200, updated task |
| PUT | `/api/tasks/{id}/status` | Set status explicitly | FR-005 | 200, updated task |
| DELETE | `/api/tasks/{id}` | Permanently delete task | FR-004 | 204, no body |

All successful mutations persist changes (FR-007). GET by ID supports editing and the creation Location header. List accepts optional `status`: All, Pending or Completed; omission means All. Results are ordered by ascending ID; empty results return an empty array.

Illustrative JSON contracts (not source code):

- Task response: `{"id":1,"title":"Sample task A","status":"Pending"}`.
- POST and PATCH request: `{"title":"Sample task A"}`. POST assigns ID and Pending on the server. PATCH changes only title, using a simple JSON object rather than a JSON Patch library.
- PUT status request: `{"status":"Completed"}`. Repeating the request leaves the task in the requested status.
- DELETE has no body; the frontend confirms before sending it.

| HTTP status | Usage |
|---|---|
| 200 | Successful retrieval/update. |
| 201 | Creation; Location points to `/api/tasks/{id}`. |
| 204 | Successful deletion. |
| 400 | Invalid input, status, filter, ID or malformed request. |
| 404 | Nonexistent task. |
| 415 | Unsupported request content type. |
| 500 | Unexpected failure. |

Use built-in ASP.NET Core Problem Details where applicable, with understandable title, status and detail fields. Handle empty/non-JSON error responses gracefully in the frontend. Duplicate titles are not conflicts.

## 5. Validation and business rules

| Rule | Implementation |
|---|---|
| BR-001 | SQLite generates unique integer IDs. |
| BR-002, BR-003 | Shared API title-validation method trims whitespace and rejects null, empty or over-255-character titles. |
| BR-004–BR-006 | Accept only Pending or Completed; default Pending; allow both transitions. |
| BR-007 | No duplicate-title check. |
| BR-008 | Native browser confirmation; only confirmed deletion sends DELETE. |
| BR-009 | Read-only filter queries. |
| BR-010, BR-011 | PATCH updates only title regardless of status. |
| BR-012 | All lists sorted by ascending ID. |
| BR-013 | All selected on opening. |
| BR-014 | Verify task existence before mutation; return 404 without affecting other records. |

Use standard .NET string length semantics with matching JavaScript validation; no specialized Unicode library. IDs are positive integers within the supported range. Validate status and filter values explicitly. Frontend validation is for convenience, not a substitute for API validation. Database constraints provide additional protection.

Use parameterized EF queries, safe plain-text DOM rendering, built-in exception handling and local logging without exposing stack traces. Bind exclusively to loopback; no authentication, authorization or CORS configuration.

## 6. Frontend

One basic page with a title input and Add button, All/Pending/Completed filters, task list, status controls, Edit/Delete buttons and simple error/empty-state feedback. Use inline title editing with Save/Cancel and native browser deletion confirmation. No advanced styling, components, external fonts, CDNs, browser storage or build tools.

Use Fetch API with relative URLs. Keep current filter, task list and editing state only. On opening, retrieve all tasks. Creation sends POST; editing sends PATCH; status changes send PUT; confirmed deletion sends DELETE. Refresh the list using the current filter after successful mutations; clear the creation input after success. Cancellation sends no deletion request. Filtering retrieves matching tasks. Display understandable errors on failure. SQLite is the source of truth.

## 7. Testing strategy

### Automated integration tests

Use xUnit and WebApplicationFactory with real SQLite temporary database files isolated per test. Never use the actual application database. Clean up temporary files. Use synthetic data only. Approximately 5–8 meaningful tests; the approved proposed set is:

| ID | Test | Main acceptance criteria |
|---|---|---|
| IT-001 | Create and retrieve task; verify ID and Pending status. | AC-001, AC-003 |
| IT-002 | Reject invalid titles on creation/editing without changing data. | AC-002, AC-006, AC-014 |
| IT-003 | Update title while preserving ID and status. | AC-005 |
| IT-004 | Delete task and verify absence. | AC-007 |
| IT-005 | Pending to Completed and back. | AC-008, AC-009 |
| IT-006 | Filter by status; verify ordering and unchanged data. | AC-010–AC-012, AC-025, AC-031 |
| IT-007 | Nonexistent-task operations fail gracefully. | AC-020, AC-028 |
| IT-008 | Restart test host with same database; verify persisted creation, editing, status and deletion. | AC-013, AC-019 |

No large unit suite, mocking frameworks, dedicated test abstractions or mandatory coverage targets.

### Manual validation

| Check | Acceptance criteria |
|---|---|
| Core UI operations in one browser | AC-001–AC-012, AC-018 |
| Empty state and default All filter | AC-004, AC-026 |
| Confirm and cancel deletion | AC-007, AC-023 |
| Title validation, trimming, boundary lengths and duplicates | AC-002, AC-006, AC-014, AC-024, AC-029, AC-030 |
| Edit completed task | AC-027 |
| Stop/restart actual application and verify saved data | AC-013, AC-019 |
| Loopback-only binding and local runtime resources/requests | AC-015, AC-016 |
| Basic responsiveness and understandable errors | AC-017, AC-020, AC-028 |
| KISS/YAGNI and synthetic data review | AC-021, AC-022 |
| User-facing tests in Edge or Chrome | AC-032 |

Inspect dependencies and frontend references, verify local requests in browser Network panel and run without restore to establish runtime independence. No need to disconnect the machine from the internet. UI and persistence validation remain separate. All 32 acceptance criteria must be verified, without requiring a separate automated test for each.

### Optional Playwright MCP

Only after the application is running in Codex, verify MCP connectivity and demonstrate one workflow: open localhost, create a synthetic task, edit title, mark Completed, delete with confirmation, verify absence. If unavailable, perform manually. See `mcp-selection.md` for evidence requirements.

## 8. Execution commands

From `C:\code\SimpleTaskManager`, after project creation in Codex:

```powershell
dotnet restore SimpleTaskManager.slnx
dotnet run --project src/SimpleTaskManager.Api
```

After initial dependency setup, run without restore:

```powershell
dotnet run --project src/SimpleTaskManager.Api --no-restore
```

Run tests:

```powershell
dotnet test SimpleTaskManager.slnx --no-restore
```

Application URL: `http://localhost:5000`, loopback only. If occupied, select another local port and document it. HTTP is appropriate for this local synthetic-data POC. No npm build, database server or migration command is required.

## 9. Incremental implementation plan

1. Verify repository, branch, exclusions, SDK and packages; initialize solution/projects and verify startup.
2. Implement entity, DbContext and SQLite initialization; verify creation and reuse.
3. Implement API endpoints, validation and business rules; verify core operations.
4. Implement basic frontend; verify user-facing operations.
5. Complete small integration suite and manual validation; verify approved acceptance criteria.
6. Optionally demonstrate Playwright MCP, complete README and present results for human acceptance.

Report changes, validation results and issues at each increment. No automatic Git commits or remote operations.

## 10. Approved decisions and remaining verification

The complete v0.2 design is approved. No additional functional requirements or outstanding design decisions. One application, two projects, one application table, six API endpoints, one frontend page, eight proposed integration tests and one optional MCP workflow.

Trade-offs: direct DbContext access keeps rules and persistence close together; EnsureCreated does not support schema evolution; integer IDs can have gaps; text status is readable; list refresh adds small local requests; temporary SQLite files add minor test overhead. Database-file loss is not recoverable within scope. Responsiveness is qualitative.

No identified development blockers. Verify actual repository state, installed SDK, compatible NuGet packages and port availability during setup. MCP connectivity remains unverified and optional. No implementation has started in Chat.

## 11. AI tool responsibilities

- ChatGPT (Chat): requirements analysis, technical design and technical decisions.
- ChatGPT (Work): project documentation and development instructions.
- Codex: application development, source changes, automated testing and browser validation using Playwright MCP.

Both approved baselines remain authoritative. Implementation is performed separately in Codex after documentation preparation. Any scope change requires explicit human approval.
