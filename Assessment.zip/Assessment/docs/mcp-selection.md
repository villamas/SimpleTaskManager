# MCP Selection — Playwright MCP

**Project:** Simple Task Manager POC  
**Selected tool:** Playwright MCP (optional browser validation)  
**Execution environment:** Codex  
**Connectivity status:** Not yet verified

## 1. Selection justification

Playwright MCP directly supports the objective of demonstrating AI-assisted development and functional validation. It allows Codex to interact with the actual application through a browser on localhost, complementing API integration tests and source inspection. It is already configured and enabled in the reported Codex environment, minimizing setup.

## 2. Why GitHub MCP was not selected

The GitHub plugin is disabled by the Enterprise administrator. Local Git commands are sufficient for the personal repository, and automated repository management, commits, pushes and merges are not required. Playwright MCP offers more direct value for validating this POC.

## 3. Intended validation workflow

Verify Playwright MCP connectivity only when the application is running in Codex. Demonstrate one basic end-to-end workflow using synthetic data:

| Step | Browser action | Expected result |
|---|---|---|
| 1 | Open the localhost application. | Application loads successfully. |
| 2 | Create a synthetic task. | Task appears with Pending status. |
| 3 | Edit its title. | Updated title is displayed. |
| 4 | Mark it Completed. | Status changes correctly. |
| 5 | Delete and accept browser confirmation. | Task disappears from the list. |

This complements the small xUnit integration suite and manual acceptance validation. No dedicated browser automation suite is required.

## 4. Benefits and limitations

| Benefits | Limitations |
|---|---|
| Validates real user interactions. | Connectivity has not been verified. |
| Exercises frontend/backend integration. | Requires a running local application. |
| Helps identify visible functional and UI issues. | One workflow does not cover every acceptance criterion. |
| Demonstrates practical AI-assisted testing. | Does not replace integration tests or human review. |
| Provides observable evidence of MCP use. | Browser connectivity and confirmation-dialog handling must be verified. |

If MCP is unavailable, perform the same workflow manually in Edge or Chrome. MCP failure is not a project blocker; manual execution must not be represented as actual MCP usage.

## 5. Evidence requirements

- Successful MCP connection and tool invocation logs.
- Browser screenshots showing creation, editing, completion and deletion results.
- Short execution record containing actions, expected results, actual results and pass/fail status.
- Errors or limitations encountered during execution.

Screenshots must be accompanied by MCP tool execution records to demonstrate actual MCP usage. All evidence must contain synthetic data only.

## 6. Status and boundaries

Playwright MCP is the selected optional tool. No changes to approved requirements v0.2 or technical design v0.2 are necessary. Actual connectivity and workflow execution remain pending in Codex. No MCP connection, browser action, dependency installation or development has been performed during selection or documentation consolidation.
